<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<head>
<!--
<link rel="stylesheet" href="style.css" type="text/css">
  -->
<style>
<?php
 //
 // Include to stylesheet, to improve the first 50%
 // of non-cached accesses to the pages.
 //
 include ("style.css");
 ?>
</style>
