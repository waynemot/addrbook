</td>
  </tr>
  <tr>
    <td width="10">&nbsp;</td>
    <td width="107" valign="top">&nbsp;</td>
    <td width="483" valign="top">
       <br>
       <?php
       if($_SERVER['SERVER_NAME'] == "php-addressbook.sourceforge.net")
       { ?>
<script type="text/javascript" 
	      src="http://www.ohloh.net/projects/25477/widgets/project_partner_badge">
</script>
        <?php } ?>
       <br>
    	 <br><a href="notes.htm">&copy; php-addressbook v<?php echo $version; ?></a></td>
  </tr>
</table>
<br>
</body>
</html> 

<!-- 
Copyright Notice:
This script was written by Rob Minto, and is free to use and distribute under GPL. 
Any improvements, please email rob(at)widgetmonkey.com. 
Keep software free. 
And please leave this copyright notice. Thanks.

Major update 2007 by Olivier Chatelain, feel free to use and distribute under GPL. 
Any improvements, please email chatelao(at)users.sourceforge.net. 

Major contribution Mark James ("famfamfam"-icons)
For more details see: http://www.famfamfam.com/lab/icons/silk/
-->